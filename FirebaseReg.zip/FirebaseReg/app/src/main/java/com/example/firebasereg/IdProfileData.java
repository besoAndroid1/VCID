package com.example.firebasereg;

public class IdProfileData {

    public String locale;

    public IdProfileData(String locale){
        this.locale = locale;
    }
}


