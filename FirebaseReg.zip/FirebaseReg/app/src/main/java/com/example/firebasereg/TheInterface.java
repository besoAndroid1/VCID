package com.example.firebasereg;

public interface TheInterface {
    public void theMethod(String result);
    public void theMethod2(String result);
  // public  String  getVoiceName(String result);


}
