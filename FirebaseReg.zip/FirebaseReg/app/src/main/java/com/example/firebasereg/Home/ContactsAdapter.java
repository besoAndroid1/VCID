package com.example.firebasereg.Home;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.example.firebasereg.R;

import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ContactViewHolder> {

    private List<Contact> contactList;
    private static Context context;
    private oneContactListener moneContactListener;

    public ContactsAdapter(List<Contact> contactList, Context context,oneContactListener oneContactListener) {
        this.contactList = contactList;
        this.context = context;
        this.moneContactListener=oneContactListener;
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        @SuppressLint("InflateParams") View view = LayoutInflater.from(context).inflate(R.layout.item_contact, null);
        return new ContactViewHolder(view,moneContactListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
        final Contact contact = contactList.get(position);
        holder.tvContactName.setText(contact.getContactName());
        holder.tvPhoneNumber.setText(contact.getContactNumber());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }

    static class ContactViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView tvContactName;
        TextView tvPhoneNumber;
        Button btn_call;
        oneContactListener oneContactListener;

        ContactViewHolder(final View itemView , oneContactListener oneContactListener) {
            super(itemView);
            tvContactName = itemView.findViewById(R.id.tv_contact_name);
            tvPhoneNumber = itemView.findViewById(R.id.tv_phone_number);
            btn_call=itemView.findViewById(R.id.button3);
           btn_call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String dial = tvPhoneNumber.getText().toString();
                    if(ContextCompat.checkSelfPermission(
                            context,android.Manifest.permission.CALL_PHONE) !=
                            PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions((Activity) context, new
                                String[]{android.Manifest.permission.CALL_PHONE}, 0);
                    } else {
                     context.startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + dial)));
                    }
                }});
            this.oneContactListener =oneContactListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            oneContactListener.onContactClick(getAdapterPosition());

        }
    }
    public interface oneContactListener{
        void onContactClick(int position);

    }
}
