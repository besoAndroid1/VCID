package com.example.firebasereg.Home;

import android.app.TabActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TabHost;

import com.example.firebasereg.R;

public class Taphost extends TabActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TabHost mTabHost=getTabHost();
        mTabHost.addTab(mTabHost.newTabSpec("main").setIndicator("Contact").
                setContent(new Intent(this, Contacts.class)));
        mTabHost.addTab(mTabHost.newTabSpec("main").setIndicator("History").
                setContent(new Intent(this,History.class)));
        mTabHost.setCurrentTab(0);
    }

    }

